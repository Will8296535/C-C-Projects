/*
* FILE		:chat-server.c
* PROJECT	:SENG2030-21W-Sytem Programming
* PROGRAMMER	:Team 15
* Description	:The chat-server is the server side of the chat system that
* 		 uses tcp sockets and threads to handle to the  clients.
*		 messaging scheme:
* Structure	:1. Where/How the server will gain knowledge will gain knowledge
*       	 of client IP and client's userID:
*		 After the client connected to the server, the first two messages that
*                the client sends to the server will be client's userID and client IP.
*		 And the server will save the value in the variables in the thread that
*		 handle the client.
*      		 2. How the server will handle the >>bye<< message and shut down/clean up
*		 after the client:
*         	 After the server received the >>bye<< message, the server will break
*		 listening loop and delete the client's socket data from socketlist (set the value to 0). 
*		 Then send the last message ">>bye<<" to that client and close the socket. 
*		 After that the thread will decrease the numClients(Global variable that 
*		 counts the number of clients) and exit the thread that handle that client.
*		 The client's input thread will exit after send the >>bye<< message and the client's
*		 output thread will exit after received >>bye<<message from server.
*     		 3. How the server data structure is managing the list of all
*     		 client?
*                The server will create a socket_list array that save the sockets value of
*		 clients.
*		 Each client id/userName will save in the variable of the thread that handle
*		 the clients.
*
*/


#include "../inc/chat-server.h"


// global variable to keep count of the number of clients
static int numClients = 0;
static int server_socket;

int main(void)
{
   int client_socket;
   int socket_list[10] = {0};
   int client_len;
   struct sockaddr_in client_addr, server_addr;
   int len, i;
   pthread_t tid[10];   
   int whichClient;
   ThreadData myData;

   // Obtain a socket for the server
   if((server_socket = socket (AF_INET, SOCK_STREAM, 0)) < 0)
   {
      printf("[SERVER] : socket() FAILED\n");
      return 1;
   }
   printf("[SERVER] : socket() successful\n");


   // initialize server address info for binding purpose
   memset(&server_addr, 0, sizeof(server_addr));
   server_addr.sin_family = AF_INET;
   server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
   server_addr.sin_port = htons (PORT);

   if(bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
   {
      printf("[SERVER] : bind() FAILED\n");
      close(server_socket);
      return 2;
   }
   printf("[SERVER] : bind() successful\n");

   // start listening on the socket
   if(listen (server_socket, 5) < 0)
   {
      printf("[SERVER] : listen() - FAILED.\n");
      close(server_socket);
      return 3;
   }
   printf("[SERVER] : listen() successful\n");

   // accept a packet from the client
   client_len = sizeof(client_addr);
   if((client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len)) < 0)
   {
      printf("[SERVER] : accept() FAILED\n");
      fflush(stdout);
      return 4;
   }
   myData.socket = client_socket;
   myData.socketList = socket_list;
   myData.ip = inet_ntoa(client_addr.sin_addr);

   // add the client_socket to socket_list


   socket_list[0] = client_socket;

/*   for(int i=0; i<10; i++)
   {
      if(socket_list[i] == 0)
      {
         socket_list[i] = client_socket;
         break;
      }
   }
*/
   numClients++;      
      
   // create a thread to take care of executing the task
   if(pthread_create(&(tid[(numClients)]), NULL, socketThread, (void *)&myData))
   {
      printf("[SERVER] : pthread_create() FAILED\n");
      fflush(stdout);
      return 5;
   }
     
   // install a signal handler
   signal(SIGALRM, alarmHandler);
   alarm(10);

   int done = 1;

   while(done)
   {
      // accept a packet from the client
      client_len = sizeof(client_addr);
      if((client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len)) < 0)
      {
         printf("[SERVER] : accept() FAILED\n");
         fflush(stdout);
         return 4;
      }
      myData.socket = client_socket;
      myData.socketList = socket_list;
      myData.ip = inet_ntoa(client_addr.sin_addr);

      // add the client_socket to socket_list
      for(int i=0; i<10; i++)
      {
         if(socket_list[i] == 0)
         {
            socket_list[i] = client_socket;
            break;
         }
      }
      numClients++;      
      
      // create a thread to take care of executing the task
      if(pthread_create(&(tid[(numClients-1)]), NULL, socketThread, (void *)&myData))
      {
         printf("[SERVER] : pthread_create() FAILED\n");
         fflush(stdout);
         return 5;
      }
   }

   close(server_socket);

   return 0;
}



/*
* FUNCTION: alarmHandler()
* DESCRIPTION: This function will check the number of
*              clients in the server every 10 seconds. 
*              If all the client is gone, it will close the server 
* PARAMETERS: signal_number
* RETURNS: none
*/


void alarmHandler(int signal_number)
{

   printf("[SERVER] : %d clients are online\n", numClients);
   if(numClients == 0)
   {
      printf("[SERVER] : No clients is connecting to the server\n");
      close(server_socket);
      exit(0);
   }
   signal (signal_number, alarmHandler);
   alarm(10); // reset alarm
}


 
/*
* FUNCTION: socketThread()
* DESCRIPTION: This function is the thread that handle a client
* PARAMETERS: data
* RETURNS: none
*/

void *socketThread(void *data)
{
   // used for accepting incoming command and also holding the command's response
   char buffer[MEGSIZ];
   char message[MEGSIZ];
   char name[10];
   int sizeOfRead;
   int timeToExit;
   time_t curtime;
   struct tm *loc_time;
   char buf[150];
   ThreadData myDataNew;

   // remap the value (void*) back to ThreadData
   myDataNew = *(ThreadData*)data;
   int *socketList = myDataNew.socketList;
   int clSocket = myDataNew.socket;
   char *ip;

   // clear out the input buffer
   memset(buffer, 0, MEGSIZ);

   // increment the numClients
   int iAmClient = numClients;

   read(clSocket, buffer, MEGSIZ);

   // the first received message is the client's name
   // save the name of the client
   strcpy(name, buffer);
   memset(buffer, 0, MEGSIZ);
   read(clSocket, buffer, MEGSIZ);

   // the second received message is the client's ip
   // save the ip of the client
   strcpy(ip, buffer);
   memset(buffer, 0, MEGSIZ);
   read(clSocket, buffer, MEGSIZ);

   while(strcmp(buffer, ">>bye<<") != 0)
   {
      // Getting current time of system
      curtime = time(NULL);
      // Coverting current time to local time
      loc_time = localtime(&curtime);
      // modify the time format
      strftime(buf, 150, "%2H:%2M:%2S", loc_time);
      
      // broadcast the message to other clients in the list
      sprintf(message, "%-15s [%-5s] << %-40s (%s)\n", ip, name, buffer, buf);

      for(int i=0; i<10; i++)
      {
         if(socketList[i] != 0 && socketList[i] != clSocket)
         {
            write(socketList[i], message, strlen(message));
         }
      }

      // send a message to the sender
      sprintf(message, "%-15s [%-5s] >> %-40s (%s)\n", ip, name, buffer, buf);
      write(clSocket, message, strlen(message));
      // clear out and get the next command and process
      memset(buffer, 0, MEGSIZ);
      read(clSocket, buffer, MEGSIZ);
   }

   // delete the data of the socket in socket list
   for(int i=0; i<10; i++)
   {
      if(socketList[i] == clSocket)
      {
         socketList[i] = 0;
      }
   }

   // write the last message to the client
   write(clSocket, buffer, strlen(buffer));

   close(clSocket);

   numClients--;
   
   // the return status will be the client # of this thread
   timeToExit = iAmClient;
   pthread_exit((void*)(timeToExit));
   
}

