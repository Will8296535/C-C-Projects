/*
* FILE		:chat-server.h
* PROJECT	:SENG2030-21W-Sytem Programming
* PROGRAMMER	:Team 15
* Description	:The file includes the libraries, constants and prototypes for chat-server application.		  
*/


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h>


#define PORT 5000
#define MEGSIZ 100
#define BUFSIZ1 40

//prototypes
void *socketThread(void *clientSocket);
void alarmHandler(int signal_number);


typedef struct
{
   int socket;
   char *ip;
   int *socketList; 
   
}ThreadData;




