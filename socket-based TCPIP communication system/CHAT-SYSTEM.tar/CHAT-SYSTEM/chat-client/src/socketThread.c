/*
* FILE		:socketThread.c
* PROJECT	:SENG2030-21W-Sytem Programming
* PROGRAMMER	:Team 15
* Description	:This file conatins the functions that use thread to handle
*                 the chat and message of the chat-client.
*/


#include "../inc/chat-client.h"


/*
* FUNCTION: inputThread()
* DESCRIPTION: This function is the thread that handle the input
*              of the chat-client and send to server.
* PARAMETERS: void *data
* RETURNS: none
*/


void *inputThread(void *data)
{
   ThreadData iThreadData;
   char buffer1[BUF];
   char buffer2[BUF];
   WINDOW *msg_win;
   int isBreak = 0;
   int msgSize = 0;
   int breakpoint = 0;
   // remap the value
   iThreadData = *((ThreadData*)data);

   int my_server_socket = iThreadData.socket;
   msg_win = iThreadData.win;
   char *name = iThreadData.name;
   int done = 1;

   // send the user name to the server
   write(my_server_socket, name, strlen(name));
   memset(buffer1, 0, BUF);

   // get the ip address of the client and send to the server
   char ip[30];
   int fd;
   struct ifreq ifr;
   fd = socket(AF_INET, SOCK_DGRAM, 0);
   ifr.ifr_addr.sa_family = AF_INET;
   memcpy(ifr.ifr_name, "eth0", IFNAMSIZ-1);
   ioctl(fd, SIOCGIFADDR, &ifr);
   close(fd);
   strcpy(ip, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));

   write(my_server_socket, ip, strlen(ip));
   memset(buffer1, 0, BUF);

   while(done)
   {
      blankWin(msg_win);
      isBreak = 0;

      // clear out the input Buffer
      memset(buffer1, 0, BUF);
   
      // get the content from the user, and fire it off to the server
      input_win(msg_win, buffer2);
 
      // check the length of the input
      if((msgSize = strlen(buffer2)) <= 40)
      {
         // if the size of the input less than 40 characters,
         // copy the input and send it
         strcpy(buffer1, buffer2);
      }
      else 
      {
         // if the size of input greater than 40, break the input to 2 message
	 
         // check if the last 5 characters contains a space
         for(int i = 35; i < 40; i++)
         {
            if(buffer2[i] == ' ')
            {
               breakpoint = i;
               
               for(int j = 0; j < i; j++)
               {
                  buffer1[j] = buffer2[j];
               }
               buffer1[i] = '\0';
               // send the first part to the server
               write(my_server_socket, buffer1, strlen(buffer1));

               // clear out the input Buffer
               memset(buffer1, 0, BUF);

               // copy the rest of the message to the buffer1
               for(int k = 0; k < (msgSize - breakpoint); k++)
               {
                  buffer1[k] = buffer2[k+ breakpoint+1];
               }
	       sleep(1);
               isBreak = 1;
               break;
            }
         }
         
         if(isBreak == 0)
         {
            for(int i = 0; i < 40; i++)
            {
               buffer1[i] = buffer2[i];
            }
            buffer1[40] = '\0';
            // send the first part to the server
            write(my_server_socket, buffer1, strlen(buffer1));

            // clear out the input Buffer
            memset(buffer1, 0, BUF);

            // copy the rest part to the buffer
            for(int i = 0; i < (msgSize - 40); i++)
            {
               buffer1[i] = buffer2[i + 40];
            }
	    sleep(1);
         }
         
      }

      // check if the user wants to quit
      if(strcmp(buffer1, ">>bye<<") == 0)
      {
         done = 0;
      }
      
      
       // send the content to the server
       write(my_server_socket, buffer1, strlen(buffer1));          
   }

   int timeToExit = 1;
   pthread_exit((void *)(timeToExit));

   return 0;
}


/*
* FUNCTION: outputThread()
* DESCRIPTION: This function is the thread that handle the received message
*              of the chat-client
* PARAMETERS:void *data
* RETURNS: none
*/


void *outputThread(void *data)
{
   ThreadData oThreadData;
   char buffer2[BUF];
   char record[10][BUF];
   char ip[50];
   WINDOW *chat_win;
   char header[100] = "-----------------------------------MESSAGES-----------------------------------";
   // remap the serverSocket value back into an INT
   oThreadData = *((ThreadData*)data);
   int my_server_socket = oThreadData.socket;
   chat_win = oThreadData.win;
   int len;
   int done = 1;
   int i = 0;
   // display the header of the messages box
   display_win(chat_win, header, 0, 0);
   while(done)
   {
      // clear out the Buffer
      memset(buffer2, 0, BUF);
   
      // receive message from server
      len = read(my_server_socket, buffer2, sizeof(buffer2));  
   
      // check if the user wants to quit
      if(strcmp(buffer2, ">>bye<<") == 0)
      {
         done = 0;
      }
      else
      {
         if(i < 10)
         { 
            display_win(chat_win, buffer2, i+1, 0);
            // save the message history
	    memset(record[i], 0, BUF);
            strcpy(record[i], buffer2);
            i++;
         }
         else
         {
            // blank the window
            blankWin(chat_win);

            //display the header of the message box
            display_win(chat_win, header, 0, 0);

            // show the history message
            for(int j=0; j<9; j++)
            {
               display_win(chat_win, record[j+1], j+1, 0);
            }

	    // show the new received message
            display_win(chat_win, buffer2, 10, 0);
 
            // update the history message
            for(int j=0; j<9; j++)
            {

	       memset(record[j], 0, BUF);
               strcpy(record[j],record[j + 1]); 
            }
            strcpy(record[9], buffer2);
             
         }
      }
   }
   
   // clean up
   close(my_server_socket);

   int timeToExit = 1;
   pthread_exit((void *)(timeToExit));

   return 0;
}

