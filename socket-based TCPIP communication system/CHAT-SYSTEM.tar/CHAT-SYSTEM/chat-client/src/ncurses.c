/*
* FILE		:ncurses.c
* PROJECT	:SENG2030-21W-Sytem Programming
* PROGRAMMER	:Team 15
* Description	:This file contains the functions of ncurses 
*                which handle the UI of the chat-client
*/


#include "../inc/chat-client.h"


/*
* FUNCTION: blankWin()
* DESCRIPTION: This function clear the content on screen.
* PARAMETERS: WINDOW *win
* RETURNS: none
*/

void blankWin(WINDOW *win)
{
  int i;
  int maxrow, maxcol;
     
  getmaxyx(win, maxrow, maxcol);
  for (i = 1; i < maxcol-2; i++)  
  {
    wmove(win, i, 1);
    refresh();
    wclrtoeol(win);
    wrefresh(win);
  }
  //box(win, 0, 0);             /* draw the box again */
  wrefresh(win);
}  



/*
 * FUNCTION: create_newwin()
 * DESCRIPTION: This function create a new window.
 * PARAMETERS: data
 * RETURNS: none
 */

WINDOW *create_newwin(int height, int width, int starty, int startx)
{       
  WINDOW *local_win;
     
  local_win = newwin(height, width, starty, startx);
  //box(local_win, 0, 0);               /* draw a box */
  wmove(local_win, 1, 1);             /* position cursor at top */
  wrefresh(local_win);     
  return local_win;
}
     


/*
 * FUNCTION: input_win()
 * DESCRIPTION: This function get the content in the window
 * PARAMETERS: WINDOW *win
 *             char *word
 * RETURNS: none
 */
 
void input_win(WINDOW *win, char *word)
{
  int i, ch;
  int maxrow, maxcol, row = 1, col = 0;
     
  blankWin(win);                          /* make it a clean window */
  getmaxyx(win, maxrow, maxcol);          /* get window size */
  bzero(word, BUF);
  wmove(win, 0, 0);                       /* position cusor at top */
  for (i = 0; (ch = wgetch(win)) != '\n'; i++) 
  {
    // set the max input size 80
    if(i >= 80)
    {
       break;
    }
    word[i] = ch;                       /* '\n' not copied */
    if (col++ < maxcol-2)               /* if within window */
    {
      wprintw(win, "%c", word[i]);      /* display the char recv'd */
    }
    else                                /* last char pos reached */
    {
      col = 1;
      if (row == maxrow-2)              /* last line in the window */
      {
        scroll(win);                    /* go up one line */
        row = maxrow-2;                 /* stay at the last line */
        wmove(win, row, col);           /* move cursor to the beginning */
        wclrtoeol(win);                 /* clear from cursor to eol */
        //box(win, 0, 0);                 /* draw the box again */
      } 
      else
      {
        row++;
        wmove(win, row, col);           /* move cursor to the beginning */
        wrefresh(win);
        wprintw(win, "%c", word[i]);    /* display the char recv'd */
      }
    }
  }
}
 
 
 
/*
 * FUNCTION: display_win()
 * DESCRIPTION: This function is to show the content to window
 * PARAMETERS: WINDOW *win
 *             char *word 
 *             int i 
 *             int shouldBlank
 * RETURNS: none
 */
    
void display_win(WINDOW *win, char *word, int i, int shouldBlank)
{
  if(shouldBlank)
  {
     blankWin(win);                          /* make it a clean window */
  }
  wmove(win, i, 1);                       /* position cusor at top */
  wprintw(win, word);
  wrefresh(win);
} 


/*
 * FUNCTION: destroy_win()
 * DESCRIPTION: This function will delete the opening window.
 * PARAMETERS: WINDOW *win
 * RETURNS: none
 */

     
void destroy_win(WINDOW *win)
{
  delwin(win);
}
     
