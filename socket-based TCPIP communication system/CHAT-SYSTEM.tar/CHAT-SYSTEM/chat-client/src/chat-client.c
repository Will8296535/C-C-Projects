/*
* FILE		:chat-client.c
* PROJECT	:SENG2030-21W-Sytem Programming
* PROGRAMMER	:Team 15
* Description	:The chat-clinet is the client side of the chat system that
* 		  uses tcp sockets and threads to talk to the server.
*/


#include "../inc/chat-client.h"

int main(int argc, char *argv[])
{
   int my_server_socket, len, done;
   pthread_t iThreadID, oThreadID;
   struct sockaddr_in server_addr;
   struct hostent* host; 
   int status;
   WINDOW *chat_win, *msg_win;
   int chat_startx, chat_starty, chat_width, chat_height;
   int msg_startx, msg_starty, msg_width, msg_height, i;
   ThreadData iThreadData, oThreadData;
   int useIP = 0;

   // Check for sanity
   if(argc != 3)
   {
      printf("USAGE: chat-client -user<userID> -server<server name>\n");
      return 1;
   }
   if(strstr(argv[1],"-user") == NULL)
   {
      printf("USAGE: chat-client -user<userID> -server<server name>\n");
      return 1;      
   }
   if(strstr(argv[2],"-server") == NULL)
   {
      printf("USAGE: chat-client -user<userID> -server<server name>\n");
      return 1;      
   }

   // extract hostname and name from cmd argc

   char *hostname = argv[2]+7;
   char *name=argv[1]+5;
   //if name is bigger than 5 characters
   if(strlen(name)>5)
   {
      *(name+5)='\0';
   }

   // check if the user enter the IP address or server's name
   if(strstr(hostname, ".") != NULL)
   {
      useIP = 1;
      if(inet_pton(AF_INET, hostname, &server_addr.sin_addr) != 1)
      {
         printf("[CLIENT] : Host Info Search - FAILED\n");
         return 2;
      }
   }
   else
   {
      // determine host info for server name supplied
      if((host = gethostbyname (hostname)) == NULL)
      {
         printf("[CLIENT] : Host Info Search - FAILED\n");
         return 2;
      }
   }

   if(useIP == 0)
   { 
      // Initialize struct to get a socket to host
      memset (&server_addr, 0, sizeof (server_addr));
      server_addr.sin_family = AF_INET;
      memcpy(&server_addr.sin_addr, host->h_addr, host->h_length);
      server_addr.sin_port = htons(PORT);
   }
   else
   {
      server_addr.sin_family = AF_INET;
      server_addr.sin_port = htons(PORT);
   }


   // Get a socket for communications
   if((my_server_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0)
   {
      printf("[CLIENT] : Getting Client Socket - FAILED\n");
      return 3;
   }

   // Attempt a connection to server
   printf("[CLIENT] : Connecting to SERVER\n");
   fflush(stdout);
   if(connect(my_server_socket, (struct socketaddr *)&server_addr, sizeof(server_addr)) < 0)
   {
      printf("[CLIENT] : Connect to Server - FAILED\n");
      close(my_server_socket);
      return 4;
   }

   // Start curses mode            
   initscr();                      
   cbreak();
   noecho();
   refresh();

   chat_height = 2;
   chat_width  = COLS - 2;
   chat_startx = 0;        
   chat_starty = 0;        
     
   msg_height = LINES - chat_height - 1;
   msg_width  = COLS;
   msg_startx = 0;        
   msg_starty = chat_height;   
      
   // create the output window 
   chat_win = create_newwin(chat_height, chat_width, chat_starty, chat_startx);
   scrollok(chat_win, TRUE);

   // create the input window 
   msg_win = create_newwin(msg_height, msg_width, msg_starty, msg_startx);
   scrollok(msg_win, TRUE);

   iThreadData.win = chat_win;
   iThreadData.socket = my_server_socket;
   iThreadData.name = name;
   oThreadData.win = msg_win;
   oThreadData.socket = my_server_socket;


   // create a thread to take care output of the message
   if(pthread_create(&(oThreadID), NULL, outputThread, (void *)&oThreadData))
   {
      printf("[CLIENT] : pthread_create() FAILED\n");
      fflush(stdout);
      return 5;
   }

   // create a thread to take care input of the message)
   if(pthread_create(&(iThreadID), NULL, inputThread, (void *)&iThreadData))
   {
      printf("[CLIENT] : pthread_create() FAILED\n");
      fflush(stdout);
      return 5;
   }
   
   // wait for the threads to complete
   if(pthread_join(iThreadID, (void *)(&status)))
   {
      printf("[CLIENT] : pthread_join() FAILED\n");
      return 6;
   }

   if(pthread_join(oThreadID, (void *)(&status)))
   {
      printf("[CLIENT] : pthread_join() FAILED\n");
      return 6;
   }

   destroy_win(chat_win);
   destroy_win(msg_win);
   endwin();   

   return 0;
}
