#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <ncurses.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>

#define PORT 5000
#define BUF 100


void *inputThread(void *);
void *outputThread(void *);

// ncurses functions
void input_win(WINDOW *, char *);
void display_win(WINDOW *win, char *word,int i,int shouldBlank);
void destroy_win(WINDOW *win);
void blankWin(WINDOW *win);
WINDOW *create_newwin(int, int, int, int);


typedef struct
{
   WINDOW *win;
   int socket;
   char *name;
}ThreadData;

